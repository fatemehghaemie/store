
package com.example.service;

import com.example.model.User;

public interface IProfileService {
    void updateProfile(User user, String name, String phoneNumber);
    void addBalance(User user, double amount);
}
