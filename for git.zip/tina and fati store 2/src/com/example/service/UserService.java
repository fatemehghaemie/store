
package com.example.service;

import com.example.model.User;
import com.example.repository.IUserRepository;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserService implements IUserService {
    private IUserRepository userRepository;

    public UserService(IUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public boolean registerUser(String username, String password, boolean isAdmin) throws NoSuchAlgorithmException {
        if (userRepository.userExists(username)) {
            return false;
        }
        String hashedPassword = hashPassword(password);
        User user = new User(username, hashedPassword, isAdmin);
        userRepository.saveUser(user);
        return true;
    }

    @Override
    public User loginUser(String username, String password) throws NoSuchAlgorithmException {
        User user = userRepository.findUserByUsername(username);
        if (user != null && user.getHashedPassword().equals(hashPassword(password))) {
            return user;
        }
        return null;
    }

    @Override
    public void updatePassword(User user, String newPassword) throws NoSuchAlgorithmException {
        user.setHashedPassword(hashPassword(newPassword));
        userRepository.saveUser(user);
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes());
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }
}
