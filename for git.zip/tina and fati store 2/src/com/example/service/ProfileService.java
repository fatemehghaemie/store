
package com.example.service;

import com.example.model.User;

public class ProfileService implements IProfileService {

    @Override
    public void updateProfile(User user, String name, String phoneNumber) {
        user.getProfile().setName(name);
        user.getProfile().setPhoneNumber(phoneNumber);
    }

    @Override
    public void addBalance(User user, double amount) {// موجودی حساب یک کاربر رو بیشتر می کنه
        user.getProfile().addBalance(amount);
    }
}