
package com.example.service;

import com.example.model.User;

import java.security.NoSuchAlgorithmException;

public interface IUserService {
    boolean registerUser(String username, String password, boolean isAdmin) throws NoSuchAlgorithmException;
    User loginUser(String username, String password) throws NoSuchAlgorithmException;
    void updatePassword(User user, String newPassword) throws NoSuchAlgorithmException;
}
//  NoSuchAlgorithmException  این خطا معمولا برای رمز نگاری اینها هست