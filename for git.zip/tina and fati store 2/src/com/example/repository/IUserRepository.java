
package com.example.repository;

import com.example.model.User;

public interface IUserRepository {
    void saveUser(User user);
    User findUserByUsername(String username);
    boolean userExists(String username);
}
