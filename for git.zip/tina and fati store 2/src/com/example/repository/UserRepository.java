package com.example.repository;

import com.example.model.User;

import java.util.HashMap;
import java.util.Map;

public class UserRepository implements IUserRepository {
    private Map<String, User> users = new HashMap<>();

    @Override
    public void saveUser(User user) {
        users.put(user.getUsername(), user);
    }

    @Override
    public User findUserByUsername(String username) {
        return users.get(username);
    }

    @Override
    public boolean userExists(String username) {
        return users.containsKey(username);
    }
}