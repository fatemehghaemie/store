package com.example.model;

public class Product {
    private int id;
    private String imagePath;

    public Product(int id, String imagePath) {
        this.id = id;
        this.imagePath = imagePath;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getImagePath() {
        return imagePath;
    }
}
