package com.example.model;

public class Profile {
    private String name;
    private String phoneNumber;
    private double balance;

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber.matches("^\\+[1-9]\\d{1,14}$")) {
            this.phoneNumber = phoneNumber;
        } else {
            throw new IllegalArgumentException("شماره تلفن نامعتبر است");
        }
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void addBalance(double amount) {
        if (amount > 0) {
            this.balance += amount;
        } else {
            throw new IllegalArgumentException("مقدار باید مثبت باشد");
        }
    }
}

