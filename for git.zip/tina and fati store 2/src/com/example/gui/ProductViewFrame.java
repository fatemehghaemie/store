

package com.example.gui;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class ProductViewFrame extends JFrame {

    public ProductViewFrame() {
        setTitle("مشاهده محصولات");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // تنظیم پنجره به اندازه کل صفحه
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(10, 4, 10, 10)); // تنظیم GridLayout با 4 ستون و 10 ردیف و فاصله 10 پیکسل
        add(new JScrollPane(panel));

        Random random = new Random();

        for (int i = 1; i <= 40; i++) { //  برای 40 تا محصول چیدمان درست می کنیم
            String imageName;
            int price;
            if (i <= 26) {
                imageName = "article (" + i + ").jpg";
                price = 800000 + random.nextInt(200001); // قیمت بین 800000 تا 1000000
            } else {
                imageName = "junkfood" + (i - 26) + ".jpg";
                price = 25000 + random.nextInt(45001); // قیمت  بین 25000 تا 70000
            }
            ImageIcon icon = new ImageIcon(imageName);//بعد از بارگذاری تصویر، شما می‌توانید این ImageIcon را به عنوان منبع تصویر برای اشیای گرافیکی دیگری مانند JLabel یا JButton استفاده کنید
            Image img = icon.getImage();
            Image scaledImg = img.getScaledInstance(100, 100, Image.SCALE_SMOOTH); // اندازه ی تصویر رو تغییر میده
            ImageIcon scaledIcon = new ImageIcon(scaledImg);

            JLabel imageLabel = new JLabel(scaledIcon);
            panel.add(imageLabel);

            JPanel infoPanel = new JPanel(new GridLayout(2, 1)); //این مخصوص برای قیمت و تومان هست

            JLabel priceLabel = new JLabel("قیمت: ");
            infoPanel.add(priceLabel);

            JLabel priceValueLabel = new JLabel(price + " تومان");
            infoPanel.add(priceValueLabel);

            panel.add(infoPanel);
        }
    }

    public static void main(String[] args) {

            new ProductViewFrame().setVisible(true);

    }
}
