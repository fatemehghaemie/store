package com.example.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SortProductsFrame extends JFrame {

    private JPanel panel;
    private JPanel panel1;

    public SortProductsFrame() {
        setTitle("مرتب‌سازی محصولات");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        panel = new JPanel(new BorderLayout());
        add(panel);

        JButton backButton = new JButton("بازگشت");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        panel.add(backButton, BorderLayout.SOUTH);

        JButton clothButton = new JButton("لباس");
        JButton fastFoodButton = new JButton("فست فود");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(clothButton);
        buttonPanel.add(fastFoodButton);
        panel.add(buttonPanel, BorderLayout.NORTH);

        panel1 = new JPanel();
        panel.add(new JScrollPane(panel1), BorderLayout.CENTER);

        clothButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel1.removeAll();
                panel1.setLayout(new GridLayout(8, 5, 10, 10));

                for (int i = 1; i <= 27; i++) {
                    String imageName = "article (" + i + ").jpg";
                    JLabel imageLabel = new JLabel(new ImageIcon(imageName));
                    panel1.add(imageLabel);

                    JPanel imagePanel = new JPanel(new BorderLayout());

                    JTextField quantityTextField = new JTextField("0", 5);
                    quantityTextField.setHorizontalAlignment(JTextField.CENTER);
                    quantityTextField.setEditable(false);
                    imagePanel.add(quantityTextField, BorderLayout.NORTH);

                    JButton minusButton = new JButton("-");
                    minusButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            int quantity = Integer.parseInt(quantityTextField.getText());
                            if (quantity > 0) {
                                quantity--;
                                quantityTextField.setText(String.valueOf(quantity));
                            }
                        }
                    });
                    imagePanel.add(minusButton, BorderLayout.WEST);

                    JButton plusButton = new JButton("+");
                    plusButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            int quantity = Integer.parseInt(quantityTextField.getText());
                            quantity++;
                            quantityTextField.setText(String.valueOf(quantity));
                        }
                    });
                    imagePanel.add(plusButton, BorderLayout.EAST);

                    panel1.add(imagePanel);
                }

                panel1.revalidate();
                panel1.repaint();
            }
        });

        fastFoodButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel1.removeAll();
                panel1.setLayout(new GridLayout(8, 5, 10, 10));

                for (int i = 1; i <= 11; i++) {
                    String imageName = "junkfood" + i + ".jpg";
                    JLabel imageLabel = new JLabel(new ImageIcon(imageName));
                    panel1.add(imageLabel);

                    JPanel imagePanel = new JPanel(new BorderLayout());JTextField quantityTextField = new JTextField("0", 5);
                    quantityTextField.setHorizontalAlignment(JTextField.CENTER);//چپ و راست متن تکسم فیلد
                    quantityTextField.setEditable(false);
                    imagePanel.add(quantityTextField, BorderLayout.NORTH);

                    JButton minusButton = new JButton("-");
                    minusButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            int quantity = Integer.parseInt(quantityTextField.getText());
                            if (quantity > 0) {
                                quantity--;
                                quantityTextField.setText(String.valueOf(quantity));
                            }
                        }
                    });
                    imagePanel.add(minusButton, BorderLayout.WEST);

                    JButton plusButton = new JButton("+");
                    plusButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            int quantity = Integer.parseInt(quantityTextField.getText());
                            quantity++;
                            quantityTextField.setText(String.valueOf(quantity));
                        }
                    });
                    imagePanel.add(plusButton, BorderLayout.EAST);

                    panel1.add(imagePanel);
                }

                panel1.revalidate();
                panel1.repaint();
            }
        });
    }
}