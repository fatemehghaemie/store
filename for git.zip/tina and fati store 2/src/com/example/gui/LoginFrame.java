

package com.example.gui;

import com.example.model.User;
import com.example.repository.IUserRepository;
import com.example.repository.UserRepository;
import com.example.service.IUserService;
import com.example.service.UserService;
import com.example.service.ProfileService;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;

public class LoginFrame extends JFrame {
    private IUserService userService;

    public LoginFrame(IUserService userService) {
        this.userService = userService;
        setTitle("ورود به سیستم");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        add(panel);
        placeComponents(panel);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel userLabel = new JLabel("نام کاربری:");
        userLabel.setBounds(10, 20, 80, 25);//junkfood
        panel.add(userLabel);

        JTextField userText = new JTextField(20);
        userText.setBounds(100, 20, 165, 25);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("رمز عبور:");
        passwordLabel.setBounds(10, 50, 80, 25);
        panel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(100, 50, 165, 25);
        panel.add(passwordText);

        JButton loginButton = new JButton("ورود");
        loginButton.setBounds(10, 80, 80, 25);
        panel.add(loginButton);

        JButton registerButton = new JButton("ثبت نام");
        registerButton.setBounds(180, 80, 80, 25);
        panel.add(registerButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();// از فیلد نام کاربری برداشتیم
                String password = new String(passwordText.getPassword());// از فیلد رمز عبور  برداشتیم
                try {
                    User user = userService.loginUser(username, password);// میاد نام کاربری و پسورد رو از سرویس می گیره
                    if (user != null) {
                        JOptionPane.showMessageDialog(panel, "ورود موفقیت‌آمیز بود");
                        if (user.isAdmin()) {

                            //بعدا باید بگم که بره به پنل مدیر
                        } else {
                            new UserPanel(userService, new ProfileService(), user).setVisible(true);
                            dispose();
                        }
                    } else {
                        JOptionPane.showMessageDialog(panel, "نام کاربری یا رمز عبور نامعتبر است");
                    }
                } catch (NoSuchAlgorithmException ex) {
                    ex.printStackTrace();
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passwordText.getPassword());
                try {
                    boolean success = userService.registerUser(username, password, false);
                    if (success) {
                        JOptionPane.showMessageDialog(panel, "ثبت نام موفقیت‌آمیز بود");
                    } else {
                        JOptionPane.showMessageDialog(panel, "نام کاربری از قبل وجود دارد");
                    }
                } catch (NoSuchAlgorithmException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    public static void main(String[] args) {
        IUserRepository userRepository = new UserRepository();
        IUserService userService = new UserService(userRepository);
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame(userService).setVisible(true);
            }
        });
    }
}
