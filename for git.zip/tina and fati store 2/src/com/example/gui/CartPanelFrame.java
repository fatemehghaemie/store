package com.example.gui;

import javax.swing.*;
import java.awt.*;// هروقت خواستی که از رابط کاربری گرافیکی استفاده کنی
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CartPanelFrame extends JFrame {

    public CartPanelFrame() {
        setTitle("پنل سبد خرید");// اسم اون  صفحه جدیده است که باز میشه
        setExtendedState(JFrame.MAXIMIZED_BOTH); // پنجره به اندازه ی کل صفحه ی نمایش باز میشه
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);// اگهEXIT_ON_CLOSE باشه برنامه به طور کامل بسته ولی در اینجا پنجره از حافظه پاک نمیشه
        setLocationRelativeTo(null);//  داره میگه نمایش پنجره در وسط و اگر می خوای که  در یک مکان خص پنجره باز شه از x,y  می تونی استفاده کنی
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(null);// یعنی دکمه در پایین قرار داره BorderLayout حالت
        add(panel);

        JButton backButton = new JButton("بازگشت");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();// یعنی پنجره ی فعلی بسته می شود و از حافظه پاک می شود
            }
        });


        panel.add(backButton);
    }
}
