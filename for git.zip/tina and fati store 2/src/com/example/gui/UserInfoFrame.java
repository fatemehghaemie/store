package com.example.gui;

import com.example.model.User;
import com.example.service.IProfileService;
import com.example.service.IUserService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserInfoFrame extends JFrame {
    private IUserService userService;
    private IProfileService profileService;
    private User user;
// یعنی از هر کدوم یه نمونه می سازیم
    public UserInfoFrame(IUserService userService, IProfileService profileService, User user) {
        this.userService = userService;
        this.profileService = profileService;
        this.user = user;
        setTitle("صفحه کاربری");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(null);// وقتی null می گذاریم یعنی طرح خاصی پیروی نمی کنه
        add(panel);
        placeComponents(panel);
    }

    private void placeComponents(JPanel panel) {

        int buttonWidth = 200;
        int buttonHeight = 40;

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();//Dimension در جاوا به منظور نمایش ابعاد یک شیء (مانند ابعاد یک پنل یا ابعاد صفحه نمایش)
        //  در واقع کد بالا ابعاد نمایشگر فعلی رو میده
        int panelWidth = (int) screenSize.getWidth();
        int rightMargin = 60; // فاصله از سمت راست صفحه
        int xPosition = panelWidth - buttonWidth - rightMargin;

        JButton userInfoButton = new JButton("اطلاعات کاربری");
        userInfoButton.setBounds(xPosition, 60, buttonWidth, buttonHeight);
        panel.add(userInfoButton);


        JLabel profileIconLabel = new JLabel();
        ImageIcon profileIcon = new ImageIcon("you.png");
        profileIconLabel.setIcon(profileIcon);// این متد برای قرار دادن یک تصویر در یک آیکون گرافیکی هست

        profileIconLabel.setBounds(xPosition + buttonWidth + 4, 45, 40, 60);
        panel.add(profileIconLabel);

        JButton sortProductsButton = new JButton("مرتب‌سازی محصولات");
        sortProductsButton.setBounds(xPosition, 110, buttonWidth, buttonHeight);
        panel.add(sortProductsButton);

        JLabel profileIconLabel1 = new JLabel();
        ImageIcon profileIcon1 = new ImageIcon("arange.png");
        profileIconLabel1.setIcon(profileIcon1);

        profileIconLabel1.setBounds(xPosition + buttonWidth + 4, 95, 40, 60);
        panel.add(profileIconLabel1);

        JButton cartPanelButton = new JButton("رفتن به پنل سبد خرید");
        cartPanelButton.setBounds(xPosition, 160, buttonWidth, buttonHeight);
        panel.add(cartPanelButton);

        JLabel profileIconLabel2 = new JLabel();
        ImageIcon profileIcon2 = new ImageIcon("MyBox.png");
        profileIconLabel2.setIcon(profileIcon2);

        profileIconLabel2.setBounds(xPosition + buttonWidth + 4, 145, 40, 60); // تنظیم موقعیت و اندازه آیکون
        panel.add(profileIconLabel2);

        JButton chatButton = new JButton("چت با پشتیبان ");
        chatButton.setBounds(xPosition, 210, buttonWidth, buttonHeight);
        panel.add(chatButton);

        JLabel profileIconLabel3 = new JLabel();
        ImageIcon profileIcon3 = new ImageIcon("supporter.png");
        profileIconLabel3.setIcon(profileIcon3);

        profileIconLabel3.setBounds(xPosition + buttonWidth + 4, 195, 40, 60); // تنظیم موقعیت و اندازه آیکون
        panel.add(profileIconLabel3);

        JButton viewProductsButton = new JButton("مشاهده محصولات");
        viewProductsButton.setBounds(xPosition, 260, buttonWidth, buttonHeight);
        panel.add(viewProductsButton);

        JLabel profileIconLabel4 = new JLabel();
        ImageIcon profileIcon4 = new ImageIcon("myProduct.png");
        profileIconLabel4.setIcon(profileIcon4);

        profileIconLabel4.setBounds(xPosition + buttonWidth + 4, 245, 40, 60); // تنظیم موقعیت و اندازه آیکون
        panel.add(profileIconLabel4);

        userInfoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showUserInfo();
            }
        });

        sortProductsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new SortProductsFrame().setVisible(true);
            }
        });

        cartPanelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CartPanelFrame().setVisible(true);
            }
        });

        chatButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ChatSupportFrame().setVisible(true);
            }
        });

        viewProductsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ProductViewFrame().setVisible(true);
            }
        });


        JLabel imageLabel = new JLabel(new ImageIcon("shopping.jpg"));
        imageLabel.setBounds(2, 50, 200, 110);
        panel.add(imageLabel);

        JLabel welcome = new JLabel("سلام به فروشگاه ما خوش آمدید:)");
        welcome.setBounds(25, 170, 200, 15);
        panel.add(welcome);
    }

    private void showUserInfo() {
        StringBuilder userInfo = new StringBuilder();//  یک کلاس است که رشته ها رو می تونه تغییر بده (StringBuilder)
        userInfo.append("نام: ").append(user.getProfile().getName()).append("\n");// append کمک می کنه که متن ها و داده ها به صورت پشت سر هم کنار هم قرار بگیرند
        userInfo.append("تلفن: ").append(user.getProfile().getPhoneNumber()).append("\n");
        userInfo.append("موجودی: ").append(user.getProfile().getBalance()).append("\n");



        JOptionPane.showMessageDialog(this, userInfo.toString(), "اطلاعات کاربر", JOptionPane.INFORMATION_MESSAGE);
    }//JOptionPane  این کلاس  برای نمایش  پنجره های پیام به کاربر استفاده می شود
    // از showMessageDialog  برای نمایش پیام به کاربر همراه با اخطار استفاده می شود
    // userInfo.toString()این قسمت رشتمون رو به رشته ی استاندارد تبدیل می کنه
    //  INFORMATION_MESSAGE  این پیام میگه که نوع پیامت از نوع اطلاعاتی است و در کل این قسمت نوع پارامتر کلاس رو مشخص می کنه

    public static void main(String[] args) {

            IUserService userService = null;
            IProfileService profileService = null;
            User user = null;
            new UserInfoFrame(userService, profileService, user).setVisible(true);// این قسمت رو همین جوری گإاشتم که مستقیما بریم صفحه ی سوم

    }
}
