package com.example.gui;

import javax.swing.*;
import com.example.model.User;
import com.example.service.IProfileService;
import com.example.service.IUserService;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UserPanel extends JFrame {
    private IUserService userService;
    private IProfileService profileService;
    private User user;

    private JTextField nameField;
    private JTextField phoneField;
    private JTextField balanceField;
    private JPasswordField passwordField;

    public UserPanel(IUserService userService, IProfileService profileService, User user) {
        this.userService = userService;
        this.profileService = profileService;
        this.user = user;
        setTitle("پنل کاربر");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        add(panel);
        placeComponents(panel);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel nameLabel = new JLabel("نام:");
        nameLabel.setBounds(10, 20, 80, 25);
        panel.add(nameLabel);

        nameField = new JTextField(20);
        nameField.setBounds(100, 20, 165, 25);
        nameField.setText(user.getProfile().getName());
        panel.add(nameField);

        JLabel phoneLabel = new JLabel("تلفن:");
        phoneLabel.setBounds(10, 50, 80, 25);
        panel.add(phoneLabel);

        phoneField = new JTextField(20);
        phoneField.setBounds(100, 50, 165, 25);
        phoneField.setText(user.getProfile().getPhoneNumber());
        panel.add(phoneField);

        JLabel balanceLabel = new JLabel("موجودی:");
        balanceLabel.setBounds(10, 80, 80, 25);
        panel.add(balanceLabel);

        balanceField = new JTextField(20);
        balanceField.setBounds(100, 80, 165, 25);
        balanceField.setText(String.valueOf(user.getProfile().getBalance()));
        panel.add(balanceField);

        JLabel passwordLabel = new JLabel("رمز عبور:");
        passwordLabel.setBounds(10, 110, 80, 25);
        panel.add(passwordLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(100, 110, 165, 25);
        panel.add(passwordField);

        JButton updateButton = new JButton("به‌روزرسانی پروفایل");
        updateButton.setBounds(10, 140, 150, 25);
        panel.add(updateButton);

        JButton addBalanceButton = new JButton("افزودن موجودی");
        addBalanceButton.setBounds(170, 140, 150, 25);
        panel.add(addBalanceButton);

        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String name = nameField.getText();
                    String phone = phoneField.getText();
                    profileService.updateProfile(user, name, phone);
                    if (passwordField.getPassword().length > 0) {
                        String password = new String(passwordField.getPassword());
                        userService.updatePassword(user, password);
                    }
                    JOptionPane.showMessageDialog(panel, "پروفایل به‌روزرسانی شد");
                    UserInfoFrame userInfoFrame = new UserInfoFrame(userService, profileService, user);
                    userInfoFrame.setVisible(true);
                    dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panel, "خطا در به‌روزرسانی پروفایل: " + ex.getMessage());
                }
            }
        });

        addBalanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double amount = Double.parseDouble(balanceField.getText());
                    profileService.addBalance(user, amount);
                    balanceField.setText(String.valueOf(user.getProfile().getBalance()));
                    JOptionPane.showMessageDialog(panel, "موجودی به‌روزرسانی شد");
                    UserInfoFrame userInfoFrame = new UserInfoFrame(userService, profileService, user);
                    userInfoFrame.setVisible(true);
                    dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(panel, "خطا در به‌روزرسانی موجودی: " + ex.getMessage());
                }
            }
        });
    }
}
