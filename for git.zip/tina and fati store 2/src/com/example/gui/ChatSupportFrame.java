package com.example.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatSupportFrame extends JFrame {

    public ChatSupportFrame() {
        setTitle("چت با پشتیبان");
        setExtendedState(JFrame.MAXIMIZED_BOTH); // تنظیم پنجره به اندازه کل صفحه
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());
        add(panel);

        JButton backButton = new JButton("بازگشت");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        panel.add(backButton, BorderLayout.SOUTH);
    }
}
